main.py为主要运行代码
train_val_model.py为训练和验证代码
test_model.py为测试代码